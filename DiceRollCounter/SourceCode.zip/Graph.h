#pragma once

class Graph {
	sf::RenderWindow& window;
	std::vector<int>* data;


public:
	struct bar : public sf::RectangleShape {// This class is public so that vector class can access it
		int index;
		int frequency;

		bar(int _index, int _frequency); // constructor
		static int maxFrequency;
		static int numberOfBars;
		static float outlineWidth;
	};

	std::vector<bar> Bars;
	const float MaxBarHeightRatio = 0.9; // Maximum ratio of the window height that a bar can reach
	sf::RectangleShape background;

	void Draw();
	void DrawBars();

	void addPoint(int index);


	void LoadData(std::vector<int>& _data);
	void MakeBars();
	void SetBarAesthetics();

	int GetDataSize() { return data->size(); }

	void SetBarHeights();
	Graph(sf::RenderWindow& window);
};

