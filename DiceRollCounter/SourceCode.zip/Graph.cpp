#include <SFML/Graphics.hpp>
#include "Graph.h"
#include <vector>
#include <iostream>
#include "Random.h"

using namespace std;

int Graph::bar::maxFrequency = 0;
int Graph::bar::numberOfBars = 0;
float Graph::bar::outlineWidth = 2.0f;

void Graph::Draw() {
    window.draw(background);
    DrawBars();

}

void Graph::DrawBars() {
    for (int i = 0; i < bar::numberOfBars; i++) {
        window.draw(Bars[i]);
    }
}

void Graph::addPoint(int value){
    if (data->size() == 20) { // verifying that dice open is a d20
        data->operator[](value - 1)++;
        Bars[value - 1].frequency++;
        SetBarAesthetics();
    }
}



void Graph::LoadData(vector<int>& _data) {
    this->data = &_data;
}

void Graph::MakeBars() {
    int size = data->size();
    bar::numberOfBars = size;

    for (int i = 0; i < size; i++) {
        Bars.push_back(bar(i, data->at(i)));
        if (data->at(i) > bar::maxFrequency)
            bar::maxFrequency = data->at(i);

    }
    SetBarAesthetics();
}
void Graph::SetBarAesthetics(){
    // setting their positions:
    int width = window.getSize().x;
    int height = window.getSize().y;

    float barwidth = width / bar::numberOfBars;

    for (int i = 0; i < bar::numberOfBars; i++) {
        Bars[i].setSize(sf::Vector2f(barwidth - bar::outlineWidth, Bars[i].frequency * 10));
        Bars[i].setOrigin(sf::Vector2f(0.0f, Bars[i].frequency * 10));
        Bars[i].setPosition(sf::Vector2f(barwidth * i, height));

        Bars[i].setFillColor(sf::Color::Blue);
        Bars[i].setOutlineColor(sf::Color::Black);
        Bars[i].setOutlineThickness(bar::outlineWidth);
    }

    //SetBarHeights(); // WIP function
}

void Graph::SetBarHeights() { // WIP
    int height = window.getSize().y;

    int totalCount = 0;
    for (int i = 0; i < bar::numberOfBars; i++)
        totalCount += Bars[i].frequency;

    float average = totalCount / (float)bar::numberOfBars;


    bool clipHeight = false;
    for (int i = 0; i < bar::numberOfBars; i++)
        if (Bars[i].frequency / average / 3 > MaxBarHeightRatio)
            clipHeight = true;

    for (int i = 0; i < bar::numberOfBars; i++)
        if (clipHeight) {
            Bars[i].setSize(sf::Vector2f(Bars[i].getSize().x, Bars[i].frequency / bar::maxFrequency * MaxBarHeightRatio * height));
        }
        else {
            Bars[i].setSize(sf::Vector2f(Bars[i].getSize().x, Bars[i].frequency / average / 3 * height));
        }
            


    int WindowHeight = window.getSize().y;
    int max = bar::maxFrequency;
    
    //float maxBarHeight = WindowHeight * MaxBar HeightRatio;
    //float fractionalBarHeight = Bar.frequency / max;



}




Graph::Graph(sf::RenderWindow& _window) : window(_window) {
    data = nullptr;
    background.setFillColor(sf::Color::White);
    background.setSize(sf::Vector2f(window.getSize()));
}

Graph::bar::bar(int _index, int _frequency){
    index = _index;
    frequency = _frequency;

    //if (frequency > maxFrequency)
      //  maxFrequency = frequency;
}