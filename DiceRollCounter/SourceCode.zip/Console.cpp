#include <iostream>
#include "Console.h"
#include <fstream>
#include <exception>
#include <sstream>
#include <vector>
#include <iomanip>

using namespace std;


vector<string> Console::readConfigurations() {
	string filename = (string)"configurations" + (string)".txt";
	//Read phase:
	vector<string> lines;

	//Read phase:
	fstream file(filename);
	string line;
	if (file.good()) {
		ifstream infile(filename, fstream::in);
		 while(getline(infile, line)) {
			lines.push_back(line);
		}
		infile.close();
	}
	else { // if file doesn't exist, write default settings and Write it
		lines.push_back("Debug_Mode: false");
		// add more default configurations here:

		
		ofstream outfile(filename, fstream::out);
		for (int i = 0; i < lines.size(); i++) {
			outfile << lines[i] << endl;
		}
	}

	//Edit phase:

	for (int i = 0; i < lines.size(); i++) {
		string str;
		istringstream lineStream(lines[i]);
		getline(lineStream, str, ' '); // Get rid of setting name. Ex: deletes "Debug-Mode: "
		getline(lineStream, str, ' ');
		lines[i] = str;
	}

	// Make everything lowercase:
	for (int index = 0; index < lines.size(); index++)
		for (int i = 0; i < lines[index].size(); i++)
			lines[index].at(i) = tolower(lines[index].at(i));

	return lines;
}




void Console::inputStage(vector<string>& input) {
	input.clear();
	string str;
	getline(cin, str);

	istringstream inStream(str);

	while (getline(inStream, str, ' ')) {
		input.push_back(str);
	}

	for (int index = 0; index < input.size(); index++)
		for (int i = 0; i < input[index].size(); i++)
			input[index].at(i) = tolower(input[index].at(i));
}
void Console::Roll(vector<string>& input) {
	if (input.size() != 3)
		throw invalid_argument("Bad input. Format example:\n Roll d20 12");
	int rollValue;

	if (input[1] == "d20") {
		// Syntax that makes sense:
		rollValue = verifyRoll(20, input);
		updateFile(20, rollValue);
		// The rest are in a simplified syntax:
	}
	else if (input[1] == "d100")
		updateFile(100, verifyRoll(100, input));
	else if (input[1] == "d12")
		updateFile(12, verifyRoll(12, input));
	else if (input[1] == "d8")
		updateFile(8, verifyRoll(8, input));
	else if (input[1] == "d6")
		updateFile(6, verifyRoll(6, input));
	else if (input[1] == "d4")
		updateFile(4, verifyRoll(4, input));
	else
		throw invalid_argument("Invalid Die.\nValid Dice include d100, d20, d8, d6, d4");

}
int Console::verifyRoll(int max, vector<string>& input) {
		int rollvalue = stoi(input[2]);

		if (rollvalue > max || rollvalue < 1)
			throw invalid_argument("Roll value outside of possible bounds");

		return rollvalue;
}

void Console::updateFile(int max, int rollValue) {
	string filename = (string)"d" + to_string(max) + (string)".dat";

	vector<int> lines;


	//Read phase:
	fstream file(filename);
	string line;
	if (file.good()) {
		ifstream infile(filename, fstream::in);
		for (int i = 0; i < max; i++) {
			getline(infile, line);
			lines.push_back(stoi(line));
		}
		infile.close();
	}
	else
		for (int i = 0; i < max; i++)
			lines.push_back(0);

	//Edit phase:
	lines[rollValue - 1]++;
	cout << "Total rolls of " << rollValue << ": " << lines[rollValue - 1] << endl;;
	//Write phase:
	ofstream outfile(filename, fstream::out);
	for (int i = 0; i < lines.size(); i++) {
		outfile << lines[i] << endl;
	}

}

void Console::GetData(vector<string>& input, vector<int>& lines) {
	if (input.size() > 3 || input.size() < 2)
		throw invalid_argument("Bad input. Format example:\n Data d20  ==or== Data d20 visual");
	int rollValue;


	if (input[1] == "d20")
		ReadData(20, lines);
	else if (input[1] == "d100")
		ReadData(100, lines);
	else if (input[1] == "d12")
		ReadData(12, lines);
	else if (input[1] == "d8")
		ReadData(8, lines);
	else if (input[1] == "d6")
		ReadData(6, lines);
	else if (input[1] == "d4")
		ReadData(4, lines);
	else
		throw invalid_argument("Invalid Die.\nValid Dice include d100, d20, d8, d6, d4");
}

void Console::ReadData(int diceMax, vector<int>& lines) {
	string filename = (string)"d" + to_string(diceMax) + (string)".dat";
	//Read phase:
	fstream file(filename);
	string line;
	if (file.good()) {
		ifstream infile(filename, fstream::in);
		for (int i = 0; i < diceMax; i++) {
			getline(infile, line);
			lines.push_back(stoi(line));
		}
		infile.close();
	}
	else
		throw invalid_argument("No data with this die available");


	printTable("Total Rolls", "Face", "Number of Rolls", diceMax, lines);
	cout << endl << endl << "Histogram:" << endl;
	printHist(diceMax, lines);
}

void Console::printTable(string title, string header1, string header2, int diceMax, vector<int> intVec) {
	// Instructions:
	// Output the information in a formatted table. The title is right justified with a setw() value of 33. 
	// Column 1 has a setw() value of 20. Column 2 has a setw() value of 23. (3 pts)

	cout << endl << setw(20) << right << title << endl;
	cout << setw(14) << left << header1 << "|" << setw(17) << right << header2 << endl;
	cout << "--------------------------------";
	for (int i = 0; i < intVec.size(); i++)
		cout << endl << setw(14) << left << i + 1 << "|" << setw(17) << right << intVec[i];

}

void Console::printHist(int diceMax, vector<int> intVec) {
	//Instructions: 
	//Output the information as a formatted histogram. 
	// Each name is right justified with a setw() value of 20. (4 pts)
	for (int i = 0; i < intVec.size(); i++) {
		cout << setw(5) << right << i + 1 << " ";
		for (int j = 0; j < intVec[i]; j++)
			cout << "*";
		cout << endl;
	}
}
